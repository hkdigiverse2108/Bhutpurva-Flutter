import express from 'express';
import { settingController } from '../controllers';
import { ROLES } from '../common';
import { roleCheck } from '../helper';

const router = express.Router();

router.post('/add-update', roleCheck([ROLES.ADMIN]), settingController.addUpdateSetting);
router.post('/get', settingController.getSetting);
router.post('/get-sgis-pdf', settingController.getSgisPdf);

export default router;